import { useEffect, useState } from 'react';
import { CircleHelp, MessageCircle, Send, X } from 'lucide-react';

type ForumReply = { id: string; body: string; createdAt: number };
type ForumPost = { id: string; title: string; createdAt: number; replies: ForumReply[] };

const STORAGE_KEY = 'isethub-forum-posts';

const seedPosts: ForumPost[] = [
  { id: 'seed-revisions', title: 'Comment organiser mes révisions avant les partiels ?', createdAt: Date.now() - 1000 * 60 * 60 * 26, replies: seedReplies(12) },
  { id: 'seed-rythme', title: 'Je me sens dépassé par le rythme, des conseils ?', createdAt: Date.now() - 1000 * 60 * 60 * 22, replies: seedReplies(8) },
  { id: 'seed-laptop', title: 'Quel laptop pour la filière IT avec un petit budget ?', createdAt: Date.now() - 1000 * 60 * 60 * 20, replies: seedReplies(21) },
];

function seedReplies(count: number): ForumReply[] {
  return Array.from({ length: count }, (_, index) => ({
    id: `seed-${index}`,
    body: 'Réponse de la communauté.',
    createdAt: Date.now() - 1000 * 60 * (index + 1),
  }));
}

function loadPosts(): ForumPost[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return seedPosts;
    const parsed = JSON.parse(raw) as ForumPost[];
    return Array.isArray(parsed) ? parsed : seedPosts;
  } catch {
    return seedPosts;
  }
}

function savePosts(posts: ForumPost[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(posts));
  } catch {
    // stockage indisponible : les publications restent en mémoire pour la session
  }
}

function timeAgo(createdAt: number) {
  const minutes = Math.max(1, Math.round((Date.now() - createdAt) / 60000));
  if (minutes < 60) return `il y a ${minutes} min`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `il y a ${hours} h`;
  return `il y a ${Math.round(hours / 24)} j`;
}

function initials(name: string) {
  return name.split(' ').filter(Boolean).slice(0, 2).map((part) => part[0].toUpperCase()).join('') || 'IS';
}

export function ForumSection() {
  const [posts, setPosts] = useState<ForumPost[]>(loadPosts);
  const [askOpen, setAskOpen] = useState(false);
  const [openPostId, setOpenPostId] = useState<string | null>(null);

  useEffect(() => {
    savePosts(posts);
  }, [posts]);

  const addPost = (title: string) => {
    setPosts((current) => [{ id: `p-${Date.now()}`, title, createdAt: Date.now(), replies: [] }, ...current]);
    setAskOpen(false);
  };

  const addReply = (postId: string, body: string) => {
    setPosts((current) => current.map((post) => (
      post.id === postId
        ? { ...post, replies: [...post.replies, { id: `r-${Date.now()}`, body, createdAt: Date.now() }] }
        : post
    )));
  };

  const openPost = posts.find((post) => post.id === openPostId) ?? null;

  return (
    <div className="grid gap-4 lg:grid-cols-[1.2fr_.8fr]">
      <div className="space-y-4">
        {posts.map((post) => (
          <article key={post.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="rounded-md bg-[#e8f7f0] px-2 py-1 text-[10px] font-black uppercase tracking-wider text-[#15915c]">Entraide</span>
              <span className="text-xs font-bold text-slate-400">
                {post.replies.length} {post.replies.length > 1 ? 'réponses' : 'réponse'}
              </span>
            </div>
            <h3 className="mt-4 font-black">{post.title}</h3>
            <div className="mt-5 flex items-center justify-between">
              <span className="flex items-center gap-2 text-xs font-bold text-slate-400">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-orange-200 text-[9px] font-bold text-[#021d33]">AN</div>
                Anonyme · {timeAgo(post.createdAt)}
              </span>
              <button onClick={() => setOpenPostId(post.id)} className="text-sm font-black text-[#126cb1]">
                Répondre <Send size={14} className="inline" />
              </button>
            </div>
          </article>
        ))}
      </div>

      <div className="rounded-2xl bg-[#021d33] p-6 text-white">
        <CircleHelp size={25} className="text-[#fab757]" />
        <h3 className="mt-5 text-xl font-black">Une question en tête ?</h3>
        <p className="mt-2 text-sm leading-6 text-blue-100">Pose-la anonymement. La communauté IsetHub est là pour répondre sans jugement.</p>
        <button onClick={() => setAskOpen(true)} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-[#fab757] px-4 py-3 text-sm font-black text-[#021d33]">
          <Send size={16} /> Poser une question
        </button>
      </div>

      {askOpen && <AskQuestionModal onClose={() => setAskOpen(false)} onSubmit={addPost} />}
      {openPost && (
        <ThreadModal
          post={openPost}
          onClose={() => setOpenPostId(null)}
          onReply={(body) => addReply(openPost.id, body)}
        />
      )}
    </div>
  );
}

function AskQuestionModal({ onClose, onSubmit }: { onClose: () => void; onSubmit: (title: string) => void }) {
  const [title, setTitle] = useState('');
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#021d33]/45 p-5 backdrop-blur-sm" onClick={onClose}>
      <div className="relative w-full max-w-md rounded-[1.5rem] bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute right-5 top-5 rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"><X size={18} /></button>
        <h2 className="pr-8 text-2xl font-black text-[#021d33]">Poser une question</h2>
        <p className="mt-1 text-sm text-slate-500">Écris ta question, la communauté s'occupe du reste.</p>
        <textarea
          autoFocus
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          rows={4}
          placeholder="Ex : Comment réviser l'analyse financière S3 en 3 jours ?"
          className="mt-5 w-full resize-none rounded-xl border border-slate-200 p-3 text-sm outline-none focus:border-[#126cb1]"
        />
        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onClose} className="rounded-xl px-4 py-2.5 text-sm font-bold text-slate-500">Annuler</button>
          <button
            disabled={!title.trim()}
            onClick={() => onSubmit(title.trim())}
            className="rounded-xl bg-[#126cb1] px-5 py-2.5 text-sm font-black text-white transition hover:bg-[#0f5b96] disabled:opacity-50"
          >
            Publier
          </button>
        </div>
      </div>
    </div>
  );
}

function ThreadModal({ post, onClose, onReply }: { post: ForumPost; onClose: () => void; onReply: (body: string) => void }) {
  const [body, setBody] = useState('');
  const submit = () => {
    if (!body.trim()) return;
    onReply(body.trim());
    setBody('');
  };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-5 backdrop-blur-sm" onClick={onClose}>
      <div className="relative flex max-h-[88vh] w-full max-w-lg flex-col overflow-hidden rounded-[1.5rem] bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute right-5 top-5 z-10 rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"><X size={18} /></button>
        <div className="border-b border-slate-100 p-6 pb-5">
          <span className="rounded-md bg-[#e8f7f0] px-2 py-1 text-[10px] font-black uppercase tracking-wider text-[#15915c]">Entraide</span>
          <h2 className="mt-3 pr-8 text-xl font-black leading-snug text-[#021d33]">{post.title}</h2>
          <p className="mt-2 flex items-center gap-2 text-xs font-bold text-slate-400">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-orange-200 text-[9px] font-bold text-[#021d33]">AN</span>
            Anonyme · {timeAgo(post.createdAt)}
          </p>
        </div>
        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto bg-[#f4f8fa] p-6">
          {post.replies.length === 0 && (
            <p className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm font-semibold text-slate-400">
              Aucune réponse pour le moment. Lance la discussion !
            </p>
          )}
          {post.replies.map((reply) => (
            <div key={reply.id} className="rounded-2xl bg-white p-4 shadow-sm">
              <p className="flex items-center gap-2 text-xs font-bold text-slate-400">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-200 text-[9px] font-bold text-[#021d33]">{initials('Étudiant ISET')}</span>
                Étudiant ISET · {timeAgo(reply.createdAt)}
              </p>
              <p className="mt-2 text-sm leading-6 text-[#021d33]">{reply.body}</p>
            </div>
          ))}
        </div>
        <div className="border-t border-slate-100 bg-white p-5">
          <div className="flex gap-2">
            <input
              value={body}
              onChange={(e) => setBody(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
              placeholder="Écris ta réponse…"
              className="h-11 flex-1 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-[#126cb1]"
            />
            <button
              onClick={submit}
              disabled={!body.trim()}
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-[#126cb1] px-4 text-sm font-black text-white transition hover:bg-[#0f5b96] disabled:opacity-50"
            >
              <MessageCircle size={16} /> Répondre
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
