import { BedDouble, CheckCircle2, MapPin, Route, Snowflake, Sofa, Utensils, Wifi } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import type { HousingListing } from '@/lib/housing';

type HousingDetailsDialogProps = {
  listing: HousingListing;
  onContact: () => void;
  onClose: () => void;
};

const amenityIcons: Record<string, LucideIcon> = {
  'Wi-Fi': Wifi,
  'Climatisation': Snowflake,
  'Meublé': Sofa,
  'Cuisine équipée': Utensils,
};

export function HousingDetailsDialog({ listing, onContact, onClose }: HousingDetailsDialogProps) {
  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="flex max-h-[90vh] w-[calc(100%-2rem)] max-w-lg flex-col gap-0 overflow-hidden rounded-[1.5rem] bg-white p-0 text-[#021d33]">
        <div className="shrink-0 overflow-hidden rounded-t-[1.5rem] bg-slate-100">
          <img
            src={listing.image_url}
            alt={`Intérieur de ${listing.title}`}
            className="aspect-[16/10] w-full object-cover"
          />
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto p-6">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-[#fab757] px-3.5 py-1.5 text-sm font-black text-[#021d33]">
              {listing.price_dt} DT / mois
            </span>
            <span className="rounded-full bg-[#eaf5fc] px-3 py-1.5 text-xs font-black text-[#126cb1]">
              {listing.property_type}
            </span>
          </div>

          <DialogTitle className="mt-4 text-2xl font-black leading-tight text-[#021d33]">{listing.title}</DialogTitle>

          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm font-semibold text-slate-600">
            <span className="flex items-center gap-1.5"><MapPin size={16} className="text-[#126cb1]" /> {listing.neighborhood}</span>
            <span className="flex items-center gap-1.5"><BedDouble size={16} className="text-[#126cb1]" /> {listing.rooms} {listing.rooms > 1 ? 'pièces' : 'pièce'}</span>
          </div>

          <DialogDescription className="mt-5 text-sm leading-6 text-slate-600">{listing.description}</DialogDescription>

          <div className="mt-6">
            <p className="text-xs font-black uppercase tracking-[.14em] text-slate-400">Équipements et accès</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {listing.amenities.map((amenity) => {
                const Icon = amenityIcons[amenity] ?? CheckCircle2;
                return (
                  <span key={amenity} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-bold text-slate-700">
                    <Icon size={14} className="text-[#126cb1]" /> {amenity}
                  </span>
                );
              })}
              <span className="inline-flex items-center gap-1.5 rounded-lg border border-[#b8dbf2] bg-[#eef7fd] px-3 py-2 text-xs font-bold text-[#126cb1]">
                <Route size={14} /> {listing.distance_to_iset}
              </span>
            </div>
          </div>

          <p className="mt-5 inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700">
            <CheckCircle2 size={14} /> {listing.available_label}
          </p>
        </div>

        <div className="shrink-0 border-t border-slate-100 bg-white p-5 sm:p-6">
          <button
            onClick={onContact}
            className="h-12 w-full rounded-xl bg-[#126cb1] px-4 text-sm font-black text-white shadow-sm transition hover:bg-[#0f5b96] active:scale-[.99]"
          >
            Contacter le propriétaire / Réserver une visite
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
