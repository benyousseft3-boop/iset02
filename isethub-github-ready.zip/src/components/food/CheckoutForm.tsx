import { useState, type FormEvent } from 'react';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { formatDinar, placeFoodOrder, type FoodItem, type Fulfilment } from '@/lib/food';

type CheckoutFormProps = {
  venueId: string;
  cart: { item: FoodItem; quantity: number }[];
  fulfilment: Fulfilment;
  feeDt: number;
  subtotalDt: number;
  onBack: () => void;
  onPlaced: (result: { orderId: string; totalDt: number }) => void;
};

const phonePattern = /^[0-9+ ]{8,20}$/;

export function CheckoutForm({ venueId, cart, fulfilment, feeDt, subtotalDt, onBack, onPlaced }: CheckoutFormProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (submitting) return;
    const trimmedName = name.trim();
    const trimmedPhone = phone.trim();
    if (trimmedName.length < 2) {
      setError('Indique ton prénom ou ton nom (2 caractères minimum).');
      return;
    }
    if (!phonePattern.test(trimmedPhone)) {
      setError('Indique un numéro de téléphone valide, par exemple 20 123 456.');
      return;
    }

    setError(null);
    setSubmitting(true);
    try {
      const result = await placeFoodOrder({
        venueId,
        customerName: trimmedName,
        customerPhone: trimmedPhone,
        fulfilment,
        lines: cart.map(({ item, quantity }) => ({ itemId: item.id, quantity })),
      });
      onPlaced(result);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'La commande n’a pas pu être envoyée.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex min-h-0 flex-1 flex-col overflow-y-auto">
      <div className="space-y-6 p-5 sm:p-6">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex h-9 items-center gap-2 rounded-lg px-2 text-sm font-bold text-[#126cb1] transition hover:bg-[#eaf5fc]"
        >
          <ArrowLeft size={16} /> Modifier mon panier
        </button>

        <div className="rounded-2xl border border-slate-200 p-4">
          <p className="text-xs font-black uppercase tracking-[.14em] text-slate-400">Récapitulatif</p>
          <ul className="mt-3 space-y-2">
            {cart.map(({ item, quantity }) => (
              <li key={item.id} className="flex items-center justify-between gap-3 text-sm">
                <span className="font-semibold text-slate-700">{quantity} × {item.name}</span>
                <span className="font-black tabular-nums text-[#021d33]">{formatDinar(item.price_dt * quantity)}</span>
              </li>
            ))}
            {feeDt > 0 && (
              <li className="flex items-center justify-between gap-3 border-t border-slate-100 pt-2 text-sm">
                <span className="font-semibold text-slate-500">Livraison campus</span>
                <span className="font-black tabular-nums text-[#021d33]">{formatDinar(feeDt)}</span>
              </li>
            )}
          </ul>
          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3">
            <span className="font-black text-[#021d33]">Total</span>
            <span className="rounded-lg bg-[#fab757] px-3 py-1 text-sm font-black text-[#021d33]">{formatDinar(subtotalDt + feeDt)}</span>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="text-sm font-bold text-slate-700">Prénom et nom</span>
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              autoComplete="name"
              maxLength={80}
              className="mt-2 h-11 w-full rounded-xl border border-slate-200 px-4 text-sm font-semibold text-[#021d33] outline-none transition placeholder:text-slate-400 focus:border-[#126cb1] focus:ring-2 focus:ring-[#126cb1]/20"
              placeholder="Ex. Amal Ben Salah"
            />
          </label>
          <label className="block">
            <span className="text-sm font-bold text-slate-700">Téléphone</span>
            <input
              value={phone}
              onChange={(event) => setPhone(event.target.value)}
              inputMode="tel"
              autoComplete="tel"
              maxLength={20}
              className="mt-2 h-11 w-full rounded-xl border border-slate-200 px-4 text-sm font-semibold text-[#021d33] outline-none transition placeholder:text-slate-400 focus:border-[#126cb1] focus:ring-2 focus:ring-[#126cb1]/20"
              placeholder="Ex. 20 123 456"
            />
          </label>
        </div>

        {error && (
          <p role="alert" className="rounded-xl bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">{error}</p>
        )}
      </div>

      <div className="mt-auto border-t border-slate-100 bg-white p-5 sm:p-6">
        <button
          type="submit"
          disabled={submitting}
          className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#126cb1] text-sm font-black text-white transition hover:bg-[#0f5b96] active:scale-[.98] disabled:cursor-wait disabled:opacity-70"
        >
          {submitting && <Loader2 size={16} className="animate-spin" />}
          Confirmer la commande
        </button>
      </div>
    </form>
  );
}
