import { BadgeCheck, Clock, ExternalLink, MapPin, Truck } from 'lucide-react';
import { formatTime, isOpenNow, type FoodVenue } from '@/lib/food';

type VenueCardProps = {
  venue: FoodVenue;
  onOpenMenu: () => void;
};

export function VenueCard({ venue, onOpenMenu }: VenueCardProps) {
  const open = isOpenNow(venue.opens_at, venue.closes_at);

  return (
    <article className="group flex flex-col overflow-hidden rounded-[1.5rem] border border-slate-200 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#126cb1]/10">
      <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
        <img
          src={venue.image_url}
          alt={`Plat servi chez ${venue.name}`}
          loading="lazy"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        <div className="absolute left-3 top-3 flex flex-wrap gap-2">
          <span
            className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-black shadow ${open ? 'bg-emerald-600 text-white' : 'bg-white text-slate-600'}`}
          >
            <span className={`h-2 w-2 rounded-full ${open ? 'bg-white' : 'bg-slate-400'}`} />
            {open ? 'Ouvert maintenant' : 'Fermé'}
          </span>
        </div>
        <div className="absolute bottom-3 left-3 flex flex-wrap gap-2">
          {venue.delivers_to_campus && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[#126cb1] px-3 py-1 text-xs font-black text-white shadow">
              <Truck size={13} /> Livraison dispo
            </span>
          )}
          {venue.student_price && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[#fab757] px-3 py-1 text-xs font-black text-[#021d33] shadow">
              <BadgeCheck size={13} /> Prix étudiant
            </span>
          )}
        </div>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-start justify-between gap-3">
          <h3 className="text-lg font-black leading-snug text-[#021d33]">{venue.name}</h3>
          <span className="shrink-0 rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600">{venue.category}</span>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm font-semibold text-slate-500">
          <span className="flex items-center gap-1.5"><MapPin size={15} className="text-[#126cb1]" /> {venue.area}</span>
          <span className="flex items-center gap-1.5"><Clock size={15} className="text-[#126cb1]" /> {formatTime(venue.opens_at)} - {formatTime(venue.closes_at)}</span>
        </div>
        {venue.maps_url && (
          <a
            href={venue.maps_url}
            target="_blank"
            rel="noreferrer"
            className="mt-3 inline-flex w-fit items-center gap-1.5 text-sm font-black text-[#126cb1] transition hover:text-[#0f5b96]"
          >
            <ExternalLink size={15} /> Voir sur Google Maps
          </a>
        )}
        <p className="mt-3 line-clamp-2 text-sm leading-6 text-slate-500">{venue.description}</p>

        <button
          onClick={onOpenMenu}
          className="mt-5 h-11 w-full rounded-xl bg-[#126cb1] text-sm font-black text-white transition hover:bg-[#0f5b96] active:scale-[.98]"
        >
          Voir le menu et commander
        </button>
      </div>
    </article>
  );
}
