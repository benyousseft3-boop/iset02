import { useEffect, useRef, useState } from 'react';
import { MessageCircle, Send, X } from 'lucide-react';

export type ChatContact = { id: string; person: string; listing: string };

type ChatMessage = { id: string; from: 'me' | 'them'; text: string; at: number };
type ChatConversation = { id: string; person: string; listing: string; messages: ChatMessage[] };

const STORAGE_KEY = 'isethub-chat-conversations';

const autoReplies = [
  'Merci pour ton message ! Je te réponds dans quelques minutes.',
  'Bonjour, oui c\'est toujours disponible. Tu veux plus de détails ?',
  'Reçu ! On peut en discuter quand tu veux.',
];

function readConversations(): ChatConversation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) as ChatConversation[] : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveConversations(list: ChatConversation[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch {
    // stockage indisponible : les conversations restent en mémoire pour la session
  }
}

function initialsOf(name: string) {
  return name.split(' ').filter(Boolean).slice(0, 2).map((part) => part[0].toUpperCase()).join('') || 'IS';
}

function timeLabel(at: number) {
  return new Date(at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

export function ChatModal({ contact, open = false, onClose }: { contact: ChatContact | null; open?: boolean; onClose: () => void }) {
  const [conversations, setConversations] = useState<ChatConversation[]>(readConversations);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [autoReplyFor, setAutoReplyFor] = useState<string | null>(null);
  const messagesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    saveConversations(conversations);
  }, [conversations]);

  useEffect(() => {
    if (!contact) return;
    setConversations((current) => (
      current.some((item) => item.id === contact.id)
        ? current
        : [{ id: contact.id, person: contact.person, listing: contact.listing, messages: [] }, ...current]
    ));
    setActiveId(contact.id);
  }, [contact]);

  useEffect(() => {
    if (!autoReplyFor) return;
    const timer = window.setTimeout(() => {
      const replies = autoReplies;
      setConversations((current) => current.map((item) => (
        item.id === autoReplyFor
          ? { ...item, messages: [...item.messages, { id: `them-${Date.now()}`, from: 'them' as const, text: replies[item.messages.length % replies.length], at: Date.now() }] }
          : item
      )));
      setAutoReplyFor(null);
    }, 1400);
    return () => window.clearTimeout(timer);
  }, [autoReplyFor]);

  const active = conversations.find((item) => item.id === activeId) ?? null;

  useEffect(() => {
    const node = messagesRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [active?.messages.length, activeId]);

  if (!contact && !open) return null;

  const ordered = [...conversations].sort((a, b) => (b.messages.at(-1)?.at ?? 0) - (a.messages.at(-1)?.at ?? 0));
  const activeFallback = active ?? (contact ? null : ordered[0] ?? null);

  const send = () => {
    const text = draft.trim();
    if (!activeFallback || !text) return;
    setConversations((current) => current.map((item) => (
      item.id === activeFallback.id
        ? { ...item, messages: [...item.messages, { id: `me-${Date.now()}`, from: 'me' as const, text, at: Date.now() }] }
        : item
    )));
    setDraft('');
    setAutoReplyFor(activeFallback.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#021d33]/60 p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="flex h-[80vh] w-full max-w-3xl overflow-hidden rounded-[1.5rem] bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-100 bg-[#f4f8fa] sm:flex">
          <p className="px-5 pb-2 pt-5 text-xs font-black uppercase tracking-[.14em] text-slate-400">Conversations</p>
          <div className="min-h-0 flex-1 overflow-y-auto px-2 pb-3">
            {ordered.length === 0 && (
              <p className="px-3 py-4 text-xs font-semibold leading-5 text-slate-400">
                Aucune conversation pour le moment.
              </p>
            )}
            {ordered.map((item) => {
              const last = item.messages.at(-1);
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveId(item.id)}
                  className={`mt-1 flex w-full items-start gap-3 rounded-xl p-3 text-left transition ${item.id === activeFallback?.id ? 'bg-[#eaf5fc]' : 'hover:bg-white'}`}
                >
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#126cb1] text-xs font-black text-white">
                    {initialsOf(item.person)}
                  </span>
                  <span className="min-w-0 flex-1">
                    <strong className="block truncate text-sm font-black text-[#021d33]">{item.person}</strong>
                    <span className="block truncate text-xs font-semibold text-slate-500">{item.listing}</span>
                    <span className="mt-0.5 block truncate text-xs text-slate-400">
                      {last ? (last.from === 'me' ? 'Vous : ' : '') + last.text : 'Nouvelle conversation'}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="flex items-center gap-3 border-b border-slate-100 p-4">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#126cb1] text-sm font-black text-white">
              {initialsOf(activeFallback?.person ?? 'IsetHub')}
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="truncate font-black text-[#021d33]">{activeFallback ? activeFallback.person : 'Messagerie IsetHub'}</h2>
              <p className="truncate text-xs font-semibold text-slate-400">{activeFallback ? activeFallback.listing : 'Tes conversations IsetHub'}</p>
            </div>
            <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700">
              <X size={18} />
            </button>
          </header>

          <div ref={messagesRef} className="min-h-0 flex-1 space-y-3 overflow-y-auto bg-[#f4f8fa] p-5">
            {(!activeFallback || activeFallback.messages.length === 0) && (
              <p className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm font-semibold text-slate-400">
                {activeFallback
                  ? 'Démarre la conversation avec une première question.'
                  : 'Aucune conversation pour le moment. Contacte un propriétaire, un conducteur ou un vendeur depuis les annonces.'}
              </p>
            )}
            {activeFallback?.messages.map((message) => (
              <div key={message.id} className={`flex ${message.from === 'me' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm leading-6 ${message.from === 'me' ? 'rounded-br-md bg-[#126cb1] text-white' : 'rounded-bl-md bg-white text-[#021d33] shadow-sm'}`}>
                  {message.text}
                  <span className={`mt-1 block text-[10px] font-bold ${message.from === 'me' ? 'text-blue-100' : 'text-slate-400'}`}>
                    {timeLabel(message.at)}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-slate-100 bg-white p-4">
            <div className="flex gap-2">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') send(); }}
                placeholder={activeFallback ? 'Écris ton message…' : 'Aucune conversation sélectionnée'}
                disabled={!activeFallback}
                className="h-11 flex-1 rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-[#126cb1] disabled:bg-slate-50"
              />
              <button
                onClick={send}
                disabled={!activeFallback || !draft.trim()}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-[#126cb1] px-4 text-sm font-black text-white transition hover:bg-[#0f5b96] disabled:opacity-50"
              >
                <Send size={16} /> Envoyer
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function ChatLauncher() {
  const [open, setOpen] = useState(false);
  const [chatCount, setChatCount] = useState(0);

  useEffect(() => {
    const update = () => {
      const count = readConversations().filter((item) => item.messages.length > 0).length;
      setChatCount(count);
    };
    update();
    window.addEventListener('focus', update);
    return () => window.removeEventListener('focus', update);
  }, []);

  const close = () => {
    setOpen(false);
    setChatCount(readConversations().filter((item) => item.messages.length > 0).length);
  };

  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Ouvrir la messagerie"
          className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#126cb1] text-white shadow-xl shadow-[#126cb1]/35 transition hover:-translate-y-1 hover:bg-[#0f5b96] active:scale-95"
        >
          <MessageCircle size={24} />
          {chatCount > 0 && (
            <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-[#fab757] px-1 text-[10px] font-black text-[#021d33] shadow">
              {chatCount}
            </span>
          )}
        </button>
      )}
      <ChatModal contact={null} open={open} onClose={close} />
    </>
  );
}
