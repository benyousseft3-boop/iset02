import { useState } from 'react';
import { X } from 'lucide-react';
import type { RideOffer } from '@/lib/rides';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';

type RideOfferModalProps = {
  onClose: () => void;
  onSubmit: (input: Omit<RideOffer, 'id'>) => Promise<void>;
};

export function RideOfferModal({ onClose, onSubmit }: RideOfferModalProps) {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [departureTime, setDepartureTime] = useState('');
  const [price, setPrice] = useState('');
  const [seats, setSeats] = useState('');
  const [daysLabel, setDaysLabel] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const valid =
    origin.trim().length >= 2 &&
    destination.trim().length >= 2 &&
    departureTime !== '' &&
    Number(price) > 0 &&
    Number(seats) >= 1;

  const submit = async () => {
    if (!valid) return;
    setSaving(true);
    try {
      await onSubmit({
        origin: origin.trim(),
        destination: destination.trim(),
        departure_time: `${departureTime}:00`.slice(0, 8),
        days_label: daysLabel.trim() || 'Tous les jours',
        note: note.trim() || 'Contacte le conducteur pour réserver ta place.',
        seats_left: Math.floor(Number(seats)),
        price_dt: Math.round(Number(price)),
      });
    } catch {
      setSaving(false);
      setError('Le trajet n’a pas pu être publié. Réessaie dans un instant.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#021d33]/45 p-5 backdrop-blur-sm">
      <div className="relative max-h-[92vh] w-full max-w-md overflow-y-auto rounded-[1.5rem] bg-white p-6 shadow-2xl">
        <button onClick={onClose} className="absolute right-5 top-5 rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700">
          <X size={18} />
        </button>
        <h2 className="pr-8 text-2xl font-black text-[#021d33]">Proposer un trajet</h2>
        <p className="mt-1 text-sm text-slate-500">Partage ton trajet avec les étudiants qui font le même chemin.</p>

        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-1">
            <Label htmlFor="ride-origin">Départ</Label>
            <Input id="ride-origin" value={origin} onChange={(e) => setOrigin(e.target.value)} placeholder="Houmt Souk" className="mt-1.5" />
          </div>
          <div className="sm:col-span-1">
            <Label htmlFor="ride-destination">Arrivée</Label>
            <Input id="ride-destination" value={destination} onChange={(e) => setDestination(e.target.value)} placeholder="ISET Djerba" className="mt-1.5" />
          </div>
          <div className="sm:col-span-1">
            <Label htmlFor="ride-time">Heure de départ</Label>
            <Input id="ride-time" type="time" value={departureTime} onChange={(e) => setDepartureTime(e.target.value)} className="mt-1.5" />
          </div>
          <div className="sm:col-span-1">
            <Label htmlFor="ride-price">Prix (DT)</Label>
            <Input id="ride-price" type="number" min={1} max={999} value={price} onChange={(e) => setPrice(e.target.value)} placeholder="2" className="mt-1.5" />
          </div>
          <div className="sm:col-span-1">
            <Label htmlFor="ride-seats">Nombre de places</Label>
            <Input id="ride-seats" type="number" min={1} max={9} value={seats} onChange={(e) => setSeats(e.target.value)} placeholder="3" className="mt-1.5" />
          </div>
          <div className="sm:col-span-1">
            <Label htmlFor="ride-days">Jours / Fréquence</Label>
            <Input id="ride-days" value={daysLabel} onChange={(e) => setDaysLabel(e.target.value)} placeholder="Lun - Ven" className="mt-1.5" />
          </div>
          <div className="sm:col-span-2">
            <Label htmlFor="ride-note">Note / Contact</Label>
            <Input id="ride-note" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Contact : 24 000 000, départ parking central…" className="mt-1.5" />
          </div>
        </div>

        {error && <p className="mt-3 rounded-lg bg-red-50 p-3 text-xs font-bold text-red-600">{error}</p>}

        <div className="mt-5 flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose} className="rounded-xl px-4 font-bold text-slate-500">
            Annuler
          </Button>
          <Button
            disabled={!valid || saving}
            onClick={submit}
            className="rounded-xl bg-[#126cb1] px-5 font-black text-white hover:bg-[#0f5b96] disabled:opacity-50"
          >
            {saving ? 'Publication…' : 'Publier le trajet'}
          </Button>
        </div>
      </div>
    </div>
  );
}
