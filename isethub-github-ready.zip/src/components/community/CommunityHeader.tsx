import type { LucideIcon } from 'lucide-react';
import { Plus } from 'lucide-react';

type CommunityHeaderProps = {
  icon: LucideIcon;
  title: string;
  subtitle?: string;
  cta?: string;
  onCta?: () => void;
};

export function CommunityHeader({ icon: Icon, title, subtitle, cta, onCta }: CommunityHeaderProps) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[#eaf5fc] text-[#126cb1]">
          <Icon size={20} />
        </div>
        <div>
          <h2 className="text-xl font-black text-[#021d33]">{title}</h2>
          {subtitle && <p className="text-sm font-semibold text-slate-400">{subtitle}</p>}
        </div>
      </div>
      {cta && onCta && (
        <button
          onClick={onCta}
          className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#fab757] px-5 text-sm font-black text-[#021d33] shadow-sm transition hover:brightness-95 active:scale-[.98] sm:w-auto"
        >
          <Plus size={17} /> {cta}
        </button>
      )}
    </div>
  );
}
