import { Check } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import { formatEventParts, type Club, type ClubEvent } from '@/lib/clubs';
import { categoryStyles } from './clubStyles';
import { ClubLogo } from './ClubLogo';

type ClubDetailsDialogProps = {
  club: Club;
  events: ClubEvent[];
  joined: boolean;
  onToggleJoin: () => void;
  onClose: () => void;
};

export function ClubDetailsDialog({ club, events, joined, onToggleJoin, onClose }: ClubDetailsDialogProps) {
  const info: { label: string; value: string }[] = [];
  if (club.founded_year) info.push({ label: 'Année de création', value: String(club.founded_year) });
  if (club.president_name) info.push({ label: 'Responsable du club', value: club.president_name });
  if (club.academic_supervisor) info.push({ label: 'Responsable académique', value: club.academic_supervisor });

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="max-h-[90vh] w-[calc(100%-2rem)] max-w-lg overflow-y-auto rounded-[1.5rem] p-0">
        <div className="p-6 pb-0">
          <div className="flex items-center gap-4">
            <ClubLogo club={club} className="h-16 w-16" iconSize={30} />
            <div className="min-w-0">
              <div className="mb-2 flex flex-wrap gap-1.5">
                {club.categories.map((category) => (
                  <span key={category} className={`rounded-md px-2 py-1 text-[10px] font-black uppercase tracking-wider ${categoryStyles[category]}`}>{category}</span>
                ))}
              </div>
              <DialogTitle className="pr-6 text-xl font-black leading-tight">{club.name}</DialogTitle>
            </div>
          </div>
          <DialogDescription className="mt-5 text-sm leading-6 text-slate-500">{club.description}</DialogDescription>
        </div>

        <div className="space-y-6 px-6">
          {info.length > 0 && (
            <dl className="grid gap-3 rounded-2xl bg-[#f4f8fa] p-4 sm:grid-cols-2">
              {info.map((item) => (
                <div key={item.label}>
                  <dt className="text-[11px] font-black uppercase tracking-wider text-slate-400">{item.label}</dt>
                  <dd className="mt-1 text-sm font-bold text-slate-700">{item.value}</dd>
                </div>
              ))}
            </dl>
          )}

          <section>
            <h3 className="mb-3 text-sm font-black uppercase tracking-wider text-[#126cb1]">Prochaines activités</h3>
            {events.length === 0 ? (
              <p className="rounded-xl border border-dashed border-slate-300 p-4 text-center text-sm font-semibold text-slate-400">Aucune activité prévue pour le moment.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {events.map((event) => {
                  const parts = formatEventParts(event.event_date);
                  return (
                    <li key={event.id} className="flex items-center gap-3 py-3">
                      <div className="flex h-12 w-12 shrink-0 flex-col items-center justify-center rounded-xl bg-[#fff4df] text-[#8a5300]">
                        <span className="text-[9px] font-black uppercase">{parts.month}</span>
                        <strong className="text-base leading-none">{parts.day}</strong>
                      </div>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-black">{event.title}</p>
                        <p className="mt-1 text-xs font-semibold text-slate-400">{parts.time} · {event.location}</p>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </div>

        <div className="border-t border-slate-100 p-6">
          <button
            onClick={onToggleJoin}
            className={`flex w-full items-center justify-center gap-1.5 rounded-xl px-4 py-3 text-sm font-black transition ${joined ? 'bg-[#e8f7f0] text-[#11704a]' : 'bg-[#126cb1] text-white hover:bg-[#0f5b96]'}`}
          >
            {joined ? <><Check size={16} /> Tu es membre de ce club</> : 'Rejoindre le club'}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
