import { supabase } from './supabase';

export type RideOffer = {
  id: string;
  origin: string;
  destination: string;
  departure_time: string;
  days_label: string;
  note: string;
  seats_left: number;
  price_dt: number;
};

const rideColumns = 'id, origin, destination, departure_time, days_label, note, seats_left, price_dt';

export async function fetchRideOffers(): Promise<RideOffer[]> {
  if (!supabase) throw new Error('La connexion à IsetHub est indisponible.');
  const { data, error } = await supabase
    .from('ride_offers')
    .select(rideColumns)
    .order('departure_time', { ascending: true });
  if (error) throw error;
  return (data ?? []) as RideOffer[];
}

export async function createRideOffer(input: Omit<RideOffer, 'id'>): Promise<RideOffer> {
  if (!supabase) throw new Error('La connexion à IsetHub est indisponible.');
  const { data, error } = await supabase
    .from('ride_offers')
    .insert(input)
    .select(rideColumns)
    .maybeSingle();
  if (error) throw error;
  if (!data) throw new Error('La publication du trajet a échoué.');
  return data as RideOffer;
}
