export type MarketItem = {
  id: string;
  title: string;
  short: string;
  price: string;
  seller: string;
  condition: string;
  description: string;
  image: string;
};

export const marketItems: MarketItem[] = [
  {
    id: 'calc-casio',
    title: 'Calculatrice Casio Graph 35+',
    short: 'Très bon état, avec housse',
    price: '85 DT',
    seller: 'Meriem',
    condition: 'Très bon état',
    description: 'Calculatrice graphique Casio Graph 35+, idéale pour les cours de mathématiques et de physique. Livrée avec sa housse de protection et sa notice. Piles récemment changées, tous les modes de calcul fonctionnent parfaitement (graphiques, statistiques, équations).',
    image: 'https://images.pexels.com/photos/220301/pexels-photo-220301.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'manuel-compta',
    title: 'Manuel de comptabilité S3',
    short: 'Édition 2024, annotations utiles',
    price: '20 DT',
    seller: 'Ahmed',
    condition: 'Bon état',
    description: 'Manuel de comptabilité pour le semestre 3, édition 2024. Les annotations au crayon des années précédentes facilitent la révision des chapitres clés (bilan, journal, comptes de résultat). Quelques pages marquées mais aucune page manquante ni déchirée.',
    image: 'https://images.pexels.com/photos/11911071/pexels-photo-11911071.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'laptop-dell-pro-16',
    title: 'PC Portable Dell Pro 16',
    short: 'Laptop pour études, très fluide',
    price: '890 DT',
    seller: 'Sami',
    condition: 'Très bon état',
    description: 'PC portable Dell Pro 16 pouces parfait pour les cours et la bureautique : prise de notes, rédaction de rapports, présentations et un peu de code. Processeur récent, 8 Go de RAM et SSD rapide, il démarre en quelques secondes et tient la journée. Chargeur d\'origine inclus, batterie en excellent état, aucun choc ni rayure marquée.',
    image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'velo-ville-etudiant',
    title: 'Vélo de ville / VTT étudiant',
    short: 'Parfait pour le trajet campus',
    price: '220 DT',
    seller: 'Nour',
    condition: 'Bon état',
    description: 'Vélo polyvalent (ville et VTT) idéal pour relier ton logement au campus d\'ISET Djerba sans dépenser un dinar de transport. Cadre solide, 6 vitesses bien réglées, freins vérifiés récemment, guidon et selle confortables. Pneus re-gonflés, chaîne graissée, prêt à rouler dès aujourd\'hui. Antivol inclus.',
    image: 'https://images.pexels.com/photos/100582/pexels-photo-100582.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
];
