/*
# Refresh food photography and map links

1. Modified Tables
- `food_venues`: add `maps_url`, the direct Google Maps search link for each restaurant.
- Existing restaurant cover photos are replaced with real Pexels photographs focused on couscous, pizza, grilled sandwiches and fish dishes.
- Existing menu photo references are refreshed for the same food themes so the restaurant cards and menus stay visually consistent.

2. Security
- Existing public read access on `food_venues` and `food_items` remains unchanged.
- No new write access is granted to the browser.

3. Important notes
- Google Maps links use the official Maps search URL format with the restaurant name and local area, so students can verify the location before ordering.
- Rows are updated by stable restaurant and dish names; no records are deleted.
- Photos are real hosted image URLs already verified for this project; no image files are downloaded into the app.
*/

ALTER TABLE public.food_venues
  ADD COLUMN IF NOT EXISTS maps_url text NOT NULL DEFAULT '';

UPDATE public.food_venues
SET
  image_url = 'https://images.pexels.com/photos/21531714/pexels-photo-21531714.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  maps_url = 'https://www.google.com/maps/search/?api=1&query=Chez+Moktar+Midoun+Djerba'
WHERE name = 'Chez Moktar';

UPDATE public.food_venues
SET
  image_url = 'https://images.pexels.com/photos/31596394/pexels-photo-31596394.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  maps_url = 'https://www.google.com/maps/search/?api=1&query=Matterello+Pizza+Houmt+Souk+Djerba'
WHERE name = 'Matterello Pizza';

UPDATE public.food_venues
SET
  image_url = 'https://images.pexels.com/photos/29954941/pexels-photo-29954941.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  maps_url = 'https://www.google.com/maps/search/?api=1&query=Brik+Belgasem+Houmt+Souk+Djerba'
WHERE name = 'Brik Belgasem';

UPDATE public.food_venues
SET
  image_url = 'https://images.pexels.com/photos/19615775/pexels-photo-19615775.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  maps_url = 'https://www.google.com/maps/search/?api=1&query=Uncle+Ali%27s+Fish+Midoun+Djerba'
WHERE name = 'Uncle Ali''s Fish';

UPDATE public.food_items
SET image_url = 'https://images.pexels.com/photos/21531714/pexels-photo-21531714.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE name = 'Couscous aux légumes';

UPDATE public.food_items
SET image_url = 'https://images.pexels.com/photos/31596394/pexels-photo-31596394.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE name = 'Pizza margherita';

UPDATE public.food_items
SET image_url = 'https://images.pexels.com/photos/34380267/pexels-photo-34380267.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE name = 'Pizza 4 fromages';

UPDATE public.food_items
SET image_url = 'https://images.pexels.com/photos/29954941/pexels-photo-29954941.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE name = 'Sandwich grillé';

UPDATE public.food_items
SET image_url = 'https://images.pexels.com/photos/19034914/pexels-photo-19034914.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE name = 'Sandwich mixte frites';

UPDATE public.food_items
SET image_url = 'https://images.pexels.com/photos/19615775/pexels-photo-19615775.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE name = 'Poisson grillé';

UPDATE public.food_items
SET image_url = 'https://images.pexels.com/photos/19034915/pexels-photo-19034915.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'
WHERE name = 'Poisson frit et frites';
