/*
# Housing listings for student accommodation

1. New Tables
- `housing_listings`: student accommodation offers shown on the Vie étudiante page.
  - `id` (uuid, primary key, fixed values for seeded rows)
  - `title` (text): listing headline
  - `property_type` (text): Studio, Appartement or Colocation
  - `neighborhood` (text): area such as Midoun or Houmt Souk
  - `rooms` (integer): number of rooms
  - `price_dt` (integer): monthly rent in dinars
  - `available_label` (text): availability message
  - `description` (text): longer presentation
  - `image_url` (text): illustration photo
  - `created_at` (timestamptz)

2. Security
- Row level security enabled on `housing_listings`.
- Anonymous and signed-in visitors can read listings (public catalogue, no sign-in in this app).
- No write access is granted to the browser; listings are managed from the database.

3. Important notes
- Seeded rows use fixed ids and `ON CONFLICT DO NOTHING`, so re-running this migration does not duplicate them.
*/

CREATE TABLE IF NOT EXISTS housing_listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  property_type text NOT NULL CHECK (property_type IN ('Studio', 'Appartement', 'Colocation')),
  neighborhood text NOT NULL,
  rooms integer NOT NULL CHECK (rooms > 0),
  price_dt integer NOT NULL CHECK (price_dt > 0),
  available_label text NOT NULL,
  description text NOT NULL,
  image_url text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE housing_listings ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON housing_listings TO anon, authenticated;

DROP POLICY IF EXISTS "public_select_housing_listings" ON housing_listings;
CREATE POLICY "public_select_housing_listings" ON housing_listings FOR SELECT
  TO anon, authenticated USING (true);

INSERT INTO housing_listings (id, title, property_type, neighborhood, rooms, price_dt, available_label, description, image_url) VALUES
  ('7f1c2a10-0001-4a00-9000-000000000001', 'Colocation calme à Midoun', 'Colocation', 'Midoun', 2, 350, '2 chambres disponibles', 'Grande maison partagée à dix minutes à pied du centre de Midoun, avec cuisine équipée, salon lumineux et accès facile aux transports vers l''ISET.', 'https://images.pexels.com/photos/19980205/pexels-photo-19980205.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'),
  ('7f1c2a10-0002-4a00-9000-000000000002', 'Studio étudiant à Houmt Souk', 'Studio', 'Houmt Souk', 1, 480, 'Disponible dès septembre', 'Studio meublé et lumineux au cœur de Houmt Souk, avec coin cuisine, lit double et rangements. Idéal pour travailler au calme.', 'https://images.pexels.com/photos/6782426/pexels-photo-6782426.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'),
  ('7f1c2a10-0003-4a00-9000-000000000003', 'Cherche colocataire près de l''ISET', 'Colocation', 'Djerba Ajim', 3, 300, 'Chambre à partager', 'Appartement de trois chambres à Ajim, à quelques minutes de l''ISET. Une chambre libre, colocataires étudiants calmes et sérieux.', 'https://images.pexels.com/photos/6782436/pexels-photo-6782436.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'),
  ('7f1c2a10-0004-4a00-9000-000000000004', 'Studio loft proche du campus', 'Studio', 'Djerba Ajim', 1, 420, 'Disponible immédiatement', 'Petit studio de style loft, cuisine américaine, lit en mezzanine et grande fenêtre. Calme et bien desservi par les bus.', 'https://images.pexels.com/photos/6447384/pexels-photo-6447384.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'),
  ('7f1c2a10-0005-4a00-9000-000000000005', 'Appartement 3 pièces à Houmt Souk', 'Appartement', 'Houmt Souk', 3, 650, 'Libre à partir d''octobre', 'Appartement spacieux avec salon ouvert sur une cuisine moderne, deux chambres et balcon. Parfait pour une colocation entre amis.', 'https://images.pexels.com/photos/7533848/pexels-photo-7533848.jpeg?auto=compress&cs=tinysrgb&h=650&w=940'),
  ('7f1c2a10-0006-4a00-9000-000000000006', 'Studio meublé à Midoun', 'Studio', 'Midoun', 1, 380, 'Disponible dès octobre', 'Studio meublé dans une résidence calme de Midoun, avec kitchenette, climatisation et connexion internet incluse.', 'https://images.pexels.com/photos/6447377/pexels-photo-6447377.jpeg?auto=compress&cs=tinysrgb&h=650&w=940')
ON CONFLICT (id) DO NOTHING;
