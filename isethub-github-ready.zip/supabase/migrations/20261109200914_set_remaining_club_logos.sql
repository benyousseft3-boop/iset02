/*
# Remaining official club logos

1. Modified Tables
- `clubs`: `logo_url` is set for 3 Zero Campus Club, Arena and ArtiVision.

2. Important notes
- Logo files are stored in the public folder.
- Re-running this migration only updates rows whose logo differs.
*/

UPDATE public.clubs SET logo_url = '/3zero.jpg' WHERE slug = 'zero-campus-club' AND logo_url IS DISTINCT FROM '/3zero.jpg';
UPDATE public.clubs SET logo_url = '/arena.jpg' WHERE slug = 'arena' AND logo_url IS DISTINCT FROM '/arena.jpg';
UPDATE public.clubs SET logo_url = '/artivision.png' WHERE slug = 'artivision' AND logo_url IS DISTINCT FROM '/artivision.png';
