/*
# Improve housing details and photography

1. Modified Tables
- `housing_listings`: add two public presentation fields.
  - `amenities` (text[]): verified amenities displayed as compact badges in the details window.
  - `distance_to_iset` (text): distance or access note shown beside the amenities.
- Existing `image_url` values are updated to warmer, more natural interior photographs already verified from Pexels.

2. Security
- Existing public read access remains unchanged.
- No browser write access is added; housing listings remain managed data.

3. Important notes
- Existing listing rows are updated by their stable titles, not generated ids.
- The new fields have safe defaults so the migration also works for any future listing created before these values are filled.
- No listings or user data are deleted.
*/

ALTER TABLE public.housing_listings
  ADD COLUMN IF NOT EXISTS amenities text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS distance_to_iset text NOT NULL DEFAULT 'Accès facile vers l’ISET';

UPDATE public.housing_listings
SET
  image_url = 'https://images.pexels.com/photos/5998063/pexels-photo-5998063.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  amenities = ARRAY['Wi-Fi', 'Meublé', 'Climatisation'],
  distance_to_iset = '15 min de l’ISET'
WHERE title = 'Colocation calme à Midoun';

UPDATE public.housing_listings
SET
  image_url = 'https://images.pexels.com/photos/19916712/pexels-photo-19916712.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  amenities = ARRAY['Wi-Fi', 'Meublé', 'Kitchenette'],
  distance_to_iset = '20 min de l’ISET'
WHERE title = 'Studio étudiant à Houmt Souk';

UPDATE public.housing_listings
SET
  image_url = 'https://images.pexels.com/photos/6890389/pexels-photo-6890389.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  amenities = ARRAY['Wi-Fi', 'Meublé', 'Cuisine équipée'],
  distance_to_iset = '10 min de l’ISET'
WHERE title = 'Cherche colocataire près de l''ISET';

UPDATE public.housing_listings
SET
  image_url = 'https://images.pexels.com/photos/6782436/pexels-photo-6782436.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  amenities = ARRAY['Meublé', 'Kitchenette', 'Calme'],
  distance_to_iset = '12 min de l’ISET'
WHERE title = 'Studio loft proche du campus';

UPDATE public.housing_listings
SET
  image_url = 'https://images.pexels.com/photos/7533848/pexels-photo-7533848.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  amenities = ARRAY['Wi-Fi', 'Cuisine équipée', 'Balcon'],
  distance_to_iset = '18 min de l’ISET'
WHERE title = 'Appartement 3 pièces à Houmt Souk';

UPDATE public.housing_listings
SET
  image_url = 'https://images.pexels.com/photos/19980199/pexels-photo-19980199.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  amenities = ARRAY['Wi-Fi', 'Meublé', 'Climatisation'],
  distance_to_iset = '15 min de l’ISET'
WHERE title = 'Studio meublé à Midoun';
