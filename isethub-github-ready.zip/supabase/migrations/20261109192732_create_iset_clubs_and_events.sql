/*
# Official ISET Djerba clubs, linked events

1. New Tables
- `clubs`: official student clubs of ISET Djerba.
  - `slug` (unique identifier used by the app), `name`, `categories` (badges: Culturel, Scientifique, Sportif, Environnement, Entrepreneuriat), `description`, `logo_url` (empty until official logos are provided), `founded_year`, `president_name`, `academic_supervisor` (all optional until confirmed).

2. Modified Tables
- `events`: new optional `club_id` column linking each event to its club. Existing columns are unchanged.

3. Seed data
- The 8 official clubs are inserted once (re-running does nothing).
- Sample upcoming events (workshops, media ateliers, sport, environment) are linked to their clubs. They can be edited or deleted later.

4. Security
- Row Level Security enabled on `clubs`. Public read-only access (anon + authenticated). No write policies, so the club list can only be changed from the database.
- `events` gets SELECT grant for anon + authenticated so the calendar can read it.

5. Important notes
- No existing data is modified or removed.
- Founding year and leadership names are left empty because they have not been confirmed.
*/

CREATE TABLE IF NOT EXISTS public.clubs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  categories text[] NOT NULL DEFAULT '{}' CHECK (categories <@ ARRAY['Culturel', 'Scientifique', 'Sportif', 'Environnement', 'Entrepreneuriat']::text[]),
  description text NOT NULL DEFAULT '',
  logo_url text,
  founded_year integer,
  president_name text,
  academic_supervisor text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.events ADD COLUMN IF NOT EXISTS club_id uuid REFERENCES public.clubs(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS events_club_id_idx ON public.events (club_id);

ALTER TABLE public.clubs ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON public.clubs TO anon, authenticated;
GRANT SELECT ON public.events TO anon, authenticated;

DROP POLICY IF EXISTS "clubs_select_public" ON public.clubs;
CREATE POLICY "clubs_select_public" ON public.clubs FOR SELECT TO anon, authenticated USING (true);

INSERT INTO public.clubs (slug, name, categories, description) VALUES
  ('zero-campus-club', '3 Zero Campus Club ISET Djerba', ARRAY['Culturel', 'Environnement'], 'Club engagé pour un campus plus propre et plus durable, avec des actions de sensibilisation et de nettoyage.'),
  ('arena', 'Arena ISET Djerba', ARRAY['Sportif'], 'Club sportif qui organise entraînements, compétitions et rencontres entre étudiants.'),
  ('artivision', 'ArtiVision ISET Djerba', ARRAY['Scientifique', 'Culturel'], 'Club créatif qui mêle arts visuels, culture et projets scientifiques.'),
  ('enactus', 'Enactus ISET Djerba', ARRAY['Scientifique', 'Culturel', 'Entrepreneuriat'], 'Club d''entrepreneuriat social qui accompagne des projets à impact pour la communauté.'),
  ('move', 'MOVE ISET Djerba', ARRAY['Scientifique', 'Culturel'], 'Club dédié à la découverte scientifique, aux échanges culturels et aux projets collectifs.'),
  ('outdoor', 'Outdoor ISET Djerba', ARRAY['Sportif'], 'Club de plein air : randonnées, sorties nature et activités sportives en extérieur.'),
  ('radio-iset-fm', 'Radio ISET / ISET FM', ARRAY['Culturel'], 'La radio des étudiants : émissions, interviews et ateliers médias.'),
  ('swug-club', 'SWUG Club ISET Djerba', ARRAY['Scientifique'], 'Club technique autour de la conception assistée par ordinateur, avec workshops SolidWorks et projets mécaniques.')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO public.events (title, club, club_id, event_date, location, capacity, description)
SELECT v.title, c.name, c.id, v.event_date::timestamptz, v.location, v.capacity, v.description
FROM (VALUES
  ('Workshop SolidWorks : premiers pas en CAO', 'swug-club', '2026-11-14 14:00:00+01', 'Atelier CAO', 30, 'Initiation à la modélisation 3D et à la mise en plan.'),
  ('Atelier média : réaliser un podcast', 'radio-iset-fm', '2026-11-17 15:00:00+01', 'Studio Radio ISET', 20, 'Du scénario au montage, les bases d''un podcast étudiant.'),
  ('Atelier vidéo et photo', 'artivision', '2026-11-20 10:00:00+01', 'Salle multimédia', 25, 'Cadrage, lumière et storytelling pour les réseaux du campus.'),
  ('Campagne de nettoyage du campus', 'zero-campus-club', '2026-11-22 09:00:00+01', 'Cour centrale', 60, 'Une matinée pour un campus plus propre, tous ensemble.'),
  ('Entraînement inter-clubs', 'arena', '2026-11-25 17:00:00+01', 'Salle omnisports', 40, 'Séance ouverte à tous les niveaux.'),
  ('Sortie randonnée', 'outdoor', '2026-11-28 07:00:00+01', 'Départ depuis l''ISET Djerba', 35, 'Une journée nature avec pique-nique partagé.'),
  ('Atelier Business Model Canvas', 'enactus', '2026-12-03 14:00:00+01', 'Amphi A', 50, 'Transformer une idée de projet en modèle économique clair.'),
  ('Hackathon MOVE', 'move', '2026-12-05 09:00:00+01', 'Lab Info 2', 40, 'Un week-end de défis scientifiques et créatifs en équipe.')
) AS v(title, club_slug, event_date, location, capacity, description)
JOIN public.clubs c ON c.slug = v.club_slug
WHERE NOT EXISTS (SELECT 1 FROM public.events e WHERE e.title = v.title);
